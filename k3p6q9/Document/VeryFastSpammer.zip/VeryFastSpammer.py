import tkinter as tk
from tkinter import messagebox, ttk, colorchooser
import time
import ctypes
import threading
from datetime import timedelta
from ctypes import wintypes

GWL_STYLE = -16
WS_MINIMIZEBOX = 0x00020000


class veryveryfastspammer:
    def __init__(self, root):
        self.root = root
        self.current_language = "zh"  # 默认中文
        self.language_texts = {
            "zh": {
                "title": "超高速刷屏器 v3.0 (Tim-CN制作)",
                "text_label": "刷屏文本:",
                "mode_label": "刷屏模式:",
                "limited_mode": "普通刷屏",
                "infinite_mode": "无限刷屏",
                "count_label": "总发送条数:",
                "fast_mode_btn": "选择 快速 刷屏速度调节模式 即 条/秒",
                "slow_mode_btn": "选择 慢速 刷屏速度调节模式 即 秒/条",
                "fast_speed_label": "发送速度(条/秒 1-500):",
                "slow_speed_label": "发送速度(秒/条 0.1-10):",
                "status_ready": "准备就绪",
                "start_btn": "开始刷屏",
                "pause_btn": "暂停",
                "resume_btn": "继续",
                "stop_btn": "停止",
                "appearance_menu": "外观设置",
                "bg_color": "选择背景颜色",
                "text_color": "选择文字颜色",
                "button_color": "选择按钮颜色",
                "default_theme": "默认主题",
                "dark_theme": "深色主题",
                "blue_theme": "蓝色主题",
                "confirm_msg_fast": "即将以 {}条/秒 的速度",
                "confirm_msg_slow": "即将以 每 {}秒/条 的速度",
                "confirm_infinite": "无限刷屏!\n(直到手动停止)",
                "confirm_limited": "发送 {} 条消息",
                "confirm_warning": "\n请在5秒内将光标移动到目标输入框\n确定开始吗?",
                "status_starting": "将在 {} 秒后开始...",
                "status_spamming": "刷屏进行中...",
                "status_paused": "已暂停",
                "status_stopping": "正在停止...",
                "status_complete": "完成! 平均速度: {:.1f}条/秒",
                "status_infinite_stopped": "无限刷屏已停止! 共发送 {} 条",
                "error_no_text": "请输入刷屏文本",
                "error_invalid_number": "请输入有效的数字",
                "error_speed_range_fast": "速度必须介于1-500条/秒",
                "error_speed_range_slow": "速度必须介于0.1-10秒/条",
                "error_send_failed": "发送过程中出错: {}",
                "elapsed_time": "已刷屏时间: {}",
                "total_time": "总用时: {}"
            },
            "en": {
                "title": "Ultra Fast Spammer v3.0 (Made by Tim-CN)",
                "text_label": "Spam Text:",
                "mode_label": "Spam Mode:",
                "limited_mode": "Limited Spam",
                "infinite_mode": "Infinite Spam",
                "count_label": "Total Messages:",
                "fast_mode_btn": "Fast Mode (messages/second)",
                "slow_mode_btn": "Slow Mode (seconds/message)",
                "fast_speed_label": "Speed (msg/sec 1-500):",
                "slow_speed_label": "Speed (sec/msg 0.1-10):",
                "status_ready": "Ready",
                "start_btn": "Start Spamming",
                "pause_btn": "Pause",
                "resume_btn": "Resume",
                "stop_btn": "Stop",
                "appearance_menu": "Appearance",
                "bg_color": "Choose Background Color",
                "text_color": "Choose Text Color",
                "button_color": "Choose Button Color",
                "default_theme": "Default Theme",
                "dark_theme": "Dark Theme",
                "blue_theme": "Blue Theme",
                "language_menu": "Language",
                "chinese": "Chinese",
                "english": "English",
                "confirm_msg_fast": "About to spam at {} messages/second",
                "confirm_msg_slow": "About to spam at 1 message every {} seconds",
                "confirm_infinite": "Infinite spamming!\n(until manually stopped)",
                "confirm_limited": "send {} messages",
                "confirm_warning": "\nPlease move cursor to target input box within 5 seconds\nConfirm to start?",
                "status_starting": "Starting in {} seconds...",
                "status_spamming": "Spamming in progress...",
                "status_paused": "Paused",
                "status_stopping": "Stopping...",
                "status_complete": "Complete! Average speed: {:.1f} msg/sec",
                "status_infinite_stopped": "Infinite spam stopped! Sent {} messages",
                "error_no_text": "Please enter spam text",
                "error_invalid_number": "Please enter a valid number",
                "error_speed_range_fast": "Speed must be between 1-500 msg/sec",
                "error_speed_range_slow": "Speed must be between 0.1-10 sec/msg",
                "error_send_failed": "Error during sending: {}",
                "elapsed_time": "Elapsed time: {}",
                "total_time": "Total time: {}"
            }
        }
        
        self.root.title(self.get_text("title"))
        self.root.geometry("500x550")  # 稍微增加高度以容纳时间显示
        self.root.configure(bg='#f0f0f0')
        self.user32 = ctypes.windll.user32
        
        # 控制变量
        self.is_spamming = False
        self.is_paused = False
        self.stop_flag = False
        self.infinite_mode = False
        self.speed_mode = "fast"
        
        # 颜色设置
        self.bg_color = '#f0f0f0'
        self.text_color = '#000000'
        self.button_color = '#4CAF50'
        self.button_text_color = '#ffffff'
        
        self.create_widgets()
        self.create_menu()

        # 新增窗口锁定初始化
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.lock_window(True)  # 初始化时锁定窗口
        
        # 确保已加载 user32.dll
        self.user32 = ctypes.windll.user32
    
    # 新增窗口锁定方法
    def lock_window(self, lock):
        """锁定/解锁窗口，防止最小化"""
        hwnd = self.user32.GetParent(self.root.winfo_id())
        style = self.user32.GetWindowLongW(hwnd, GWL_STYLE)
        
        if lock:
            # 移除最小化按钮
            self.user32.SetWindowLongW(hwnd, GWL_STYLE, style & ~WS_MINIMIZEBOX)
            self.root.resizable(False, False)
            self.root.attributes("-topmost", True)  # 窗口置顶
        else:
            # 恢复最小化按钮
            self.user32.SetWindowLongW(hwnd, GWL_STYLE, style | WS_MINIMIZEBOX)
            self.root.resizable(True, True)
            self.root.attributes("-topmost", False)
    
    # 新增关闭事件处理
    def on_close(self):
        """窗口关闭时恢复窗口样式"""
        self.lock_window(False)
        self.root.destroy()
        
    def get_text(self, key):
        """获取当前语言的文本"""
        return self.language_texts[self.current_language].get(key, key)
    
    def update_language(self, lang):
        """更新界面语言"""
        self.current_language = lang
        self.root.title(self.get_text("title"))
        self.update_all_texts()
    
    def update_all_texts(self):
        """更新所有界面文本"""
        # 更新菜单文本
        self.appearance_menu.entryconfig(0, label=self.get_text("bg_color"))
        self.appearance_menu.entryconfig(1, label=self.get_text("text_color"))
        self.appearance_menu.entryconfig(2, label=self.get_text("button_color"))
        self.appearance_menu.entryconfig(4, label=self.get_text("default_theme"))
        self.appearance_menu.entryconfig(5, label=self.get_text("dark_theme"))
        self.appearance_menu.entryconfig(6, label=self.get_text("blue_theme"))
        
        # 更新主界面文本
        self.text_label.config(text=self.get_text("text_label"))
        self.mode_label.config(text=self.get_text("mode_label"))
        self.limited_radio.config(text=self.get_text("limited_mode"))
        self.infinite_radio.config(text=self.get_text("infinite_mode"))
        self.count_label.config(text=self.get_text("count_label"))
        self.fast_mode_btn.config(text=self.get_text("fast_mode_btn"))
        self.slow_mode_btn.config(text=self.get_text("slow_mode_btn"))
        self.fast_speed_label.config(text=self.get_text("fast_speed_label"))
        self.slow_speed_label.config(text=self.get_text("slow_speed_label"))
        self.status_label.config(text=self.get_text("status_ready"))
        self.start_btn.config(text=self.get_text("start_btn"))
        self.pause_btn.config(text=self.get_text("pause_btn"))
        self.stop_btn.config(text=self.get_text("stop_btn"))
    
    def create_menu(self):
        """创建顶部菜单栏"""
        menubar = tk.Menu(self.root)

        # 外观菜单 - 名称会随语言变化
        self.appearance_menu = tk.Menu(menubar, tearoff=0)
        self.appearance_menu.add_command(label=self.get_text("bg_color"), command=self.choose_bg_color)
        self.appearance_menu.add_command(label=self.get_text("text_color"), command=self.choose_text_color)
        self.appearance_menu.add_command(label=self.get_text("button_color"), command=self.choose_button_color)
        self.appearance_menu.add_separator()
        self.appearance_menu.add_command(label=self.get_text("default_theme"), command=self.set_default_theme)
        self.appearance_menu.add_command(label=self.get_text("dark_theme"), command=self.set_dark_theme)
        self.appearance_menu.add_command(label=self.get_text("blue_theme"), command=self.set_blue_theme)
        menubar.add_cascade(label="Theme/外观设置 (Alt+T)", menu=self.appearance_menu)

        # 语言菜单 - 名称固定为"Language/语言设置"
        language_menu = tk.Menu(menubar, tearoff=0)
        # 子菜单项固定为"简体中文"和"English"
        language_menu.add_command(label="简体中文", command=lambda: self.update_language("zh"))
        language_menu.add_command(label="English", command=lambda: self.update_language("en"))
        menubar.add_cascade(label="Language/语言设置 (Alt+L)", menu=language_menu)

        self.root.config(menu=menubar)
    
    def choose_bg_color(self):
        """选择背景颜色"""
        color = colorchooser.askcolor(title=self.get_text("bg_color"))[1]
        if color:
            self.bg_color = color
            self.root.configure(bg=color)
            for widget in self.root.winfo_children():
                if isinstance(widget, (tk.Frame, ttk.Frame)):
                    widget.configure(bg=color)
    
    def choose_text_color(self):
        """选择文字颜色"""
        color = colorchooser.askcolor(title=self.get_text("text_color"))[1]
        if color:
            self.text_color = color
            self.update_colors()
    
    def choose_button_color(self):
        """选择按钮颜色"""
        color = colorchooser.askcolor(title=self.get_text("button_color"))[1]
        if color:
            self.button_color = color
            self.update_button_colors()
    
    def set_default_theme(self):
        """设置默认主题"""
        self.bg_color = '#f0f0f0'
        self.text_color = '#000000'
        self.button_color = '#4CAF50'
        self.button_text_color = '#ffffff'
        self.apply_theme()
    
    def set_dark_theme(self):
        """设置深色主题"""
        self.bg_color = '#2d2d2d'
        self.text_color = '#ffffff'
        self.button_color = '#555555'
        self.button_text_color = '#ffffff'
        self.apply_theme()
    
    def set_blue_theme(self):
        """设置蓝色主题"""
        self.bg_color = '#e6f3ff'
        self.text_color = '#003366'
        self.button_color = '#0078d7'
        self.button_text_color = '#ffffff'
        self.apply_theme()
    
    def apply_theme(self):
        """应用当前主题"""
        self.root.configure(bg=self.bg_color)
        self.update_colors()
        self.update_button_colors()
        
        # 更新所有框架的背景色
        for widget in self.root.winfo_children():
            if isinstance(widget, (tk.Frame, ttk.Frame)):
                widget.configure(bg=self.bg_color)
    
    def update_colors(self):
        """更新所有文本颜色"""
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Label):
                widget.config(fg=self.text_color, bg=self.bg_color)
            elif isinstance(widget, tk.Entry):
                widget.config(fg=self.text_color, bg='white')
            elif isinstance(widget, tk.Radiobutton):
                widget.config(fg=self.text_color, bg=self.bg_color)
            elif isinstance(widget, tk.Spinbox):
                widget.config(fg=self.text_color, bg='white')
        
        self.status_label.config(fg=self.text_color, bg=self.bg_color)
        self.time_label.config(fg=self.text_color, bg=self.bg_color)
    
    def update_button_colors(self):
        """更新所有按钮颜色"""
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Button):
                widget.config(bg=self.button_color, fg=self.button_text_color,
                             activebackground=self.button_color, activeforeground=self.button_text_color)
    
    def create_widgets(self):
        # 主框架
        main_frame = tk.Frame(self.root, bg=self.bg_color)
        main_frame.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
        
        # 刷屏文本
        text_frame = tk.Frame(main_frame, bg=self.bg_color)
        text_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.text_label = tk.Label(text_frame, text=self.get_text("text_label"), bg=self.bg_color, fg=self.text_color)
        self.text_label.pack(side=tk.LEFT)
        self.text_entry = tk.Entry(text_frame, width=50, font=('Arial', 10))
        self.text_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # 模式选择
        mode_frame = tk.Frame(main_frame, bg=self.bg_color)
        mode_frame.pack(fill=tk.X, pady=5)
        
        self.mode_label = tk.Label(mode_frame, text=self.get_text("mode_label"), bg=self.bg_color, fg=self.text_color)
        self.mode_label.pack(side=tk.LEFT)
        
        self.mode_var = tk.StringVar(value="limited")
        mode_radio_frame = tk.Frame(mode_frame, bg=self.bg_color)
        mode_radio_frame.pack(side=tk.LEFT, padx=10)
        
        self.limited_radio = tk.Radiobutton(mode_radio_frame, text=self.get_text("limited_mode"), variable=self.mode_var, 
                      value="limited", command=self.toggle_mode, bg=self.bg_color, fg=self.text_color,
                      selectcolor=self.bg_color)
        self.limited_radio.pack(side=tk.LEFT, padx=5)
        
        self.infinite_radio = tk.Radiobutton(mode_radio_frame, text=self.get_text("infinite_mode"), variable=self.mode_var, 
                      value="infinite", command=self.toggle_mode, bg=self.bg_color, fg=self.text_color,
                      selectcolor=self.bg_color)
        self.infinite_radio.pack(side=tk.LEFT, padx=5)
        
        # 刷屏次数（有限模式）
        self.count_frame = tk.Frame(main_frame, bg=self.bg_color)
        self.count_frame.pack(fill=tk.X, pady=5)
        
        self.count_label = tk.Label(self.count_frame, text=self.get_text("count_label"), bg=self.bg_color, fg=self.text_color)
        self.count_label.pack(side=tk.LEFT)
        self.count_spin = tk.Spinbox(self.count_frame, from_=1, to=100000, width=8, font=('Arial', 10))
        self.count_spin.pack(side=tk.LEFT, padx=5)
        
        # 速度模式选择
        speed_mode_frame = tk.Frame(main_frame, bg=self.bg_color)
        speed_mode_frame.pack(fill=tk.X, pady=5)
        
        # 快速模式按钮
        self.fast_mode_btn = tk.Button(speed_mode_frame, text=self.get_text("fast_mode_btn"), 
                                     command=lambda: self.set_speed_mode("fast"),
                                     bg=self.button_color, fg=self.button_text_color,
                                     font=('Arial', 9))
        self.fast_mode_btn.pack(side=tk.LEFT, padx=5)
        
        # 慢速模式按钮
        self.slow_mode_btn = tk.Button(speed_mode_frame, text=self.get_text("slow_mode_btn"), 
                                     command=lambda: self.set_speed_mode("slow"),
                                     bg=self.button_color, fg=self.button_text_color,
                                     font=('Arial', 9))
        self.slow_mode_btn.pack(side=tk.LEFT, padx=5)
        
        # 快速速度调节（条/秒）
        self.fast_speed_frame = tk.Frame(main_frame, bg=self.bg_color)
        self.fast_speed_frame.pack(fill=tk.X, pady=5)
        
        self.fast_speed_label = tk.Label(self.fast_speed_frame, text=self.get_text("fast_speed_label"), bg=self.bg_color, fg=self.text_color)
        self.fast_speed_label.pack(side=tk.LEFT)
        self.fast_speed_scale = tk.Scale(self.fast_speed_frame, from_=1, to=500, orient=tk.HORIZONTAL, 
                                      length=300, bg=self.bg_color, fg=self.text_color,
                                      highlightbackground=self.bg_color)
        self.fast_speed_scale.set(50)
        self.fast_speed_scale.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # 慢速速度调节（秒/条）
        self.slow_speed_frame = tk.Frame(main_frame, bg=self.bg_color)
        self.slow_speed_frame.pack(fill=tk.X, pady=5)
        
        self.slow_speed_label = tk.Label(self.slow_speed_frame, text=self.get_text("slow_speed_label"), bg=self.bg_color, fg=self.text_color)
        self.slow_speed_label.pack(side=tk.LEFT)
        self.slow_speed_scale = tk.Scale(self.slow_speed_frame, from_=0.1, to=10, resolution=0.1, orient=tk.HORIZONTAL, 
                                      length=300, bg=self.bg_color, fg=self.text_color,
                                      highlightbackground=self.bg_color)
        self.slow_speed_scale.set(1.0)
        self.slow_speed_scale.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # 默认启用快速模式
        self.set_speed_mode("fast")
        
        # 状态显示
        status_frame = tk.Frame(main_frame, bg=self.bg_color)
        status_frame.pack(fill=tk.X, pady=(10, 5))
        
        self.status_label = tk.Label(status_frame, text=self.get_text("status_ready"), fg="blue", 
                                   font=('Arial', 10, 'bold'), bg=self.bg_color)
        self.status_label.pack()
        
        # 刷屏时间显示
        self.time_label = tk.Label(status_frame, text="", fg="purple",
                                 font=('Arial', 9), bg=self.bg_color)
        self.time_label.pack()
        
        # 进度条
        progress_frame = tk.Frame(main_frame, bg=self.bg_color)
        progress_frame.pack(fill=tk.X, pady=5)
        
        self.progress = ttk.Progressbar(progress_frame, orient="horizontal", 
                                       length=400, mode="determinate")
        self.progress.pack(fill=tk.X)
        
        # 按钮框架
        button_frame = tk.Frame(main_frame, bg=self.bg_color)
        button_frame.pack(pady=(15, 0))
        
        # 开始按钮
        self.start_btn = tk.Button(button_frame, text=self.get_text("start_btn"), 
                                 command=self.start_spamming,
                                 width=12, height=2,
                                 bg=self.button_color, fg=self.button_text_color,
                                 font=('Arial', 10, 'bold'),
                                 relief=tk.RAISED, bd=2)
        self.start_btn.pack(side=tk.LEFT, padx=10)
        
        # 暂停按钮（初始禁用）
        self.pause_btn = tk.Button(button_frame, text=self.get_text("pause_btn"),
                                 command=self.pause_resume,
                                 state=tk.DISABLED,
                                 width=12, height=2,
                                 bg=self.button_color, fg=self.button_text_color,
                                 font=('Arial', 10, 'bold'),
                                 relief=tk.RAISED, bd=2)
        self.pause_btn.pack(side=tk.LEFT, padx=10)
        
        # 停止按钮（初始禁用）
        self.stop_btn = tk.Button(button_frame, text=self.get_text("stop_btn"),
                                command=self.stop_spamming,
                                state=tk.DISABLED,
                                width=12, height=2,
                                bg=self.button_color, fg=self.button_text_color,
                                font=('Arial', 10, 'bold'),
                                relief=tk.RAISED, bd=2)
        self.stop_btn.pack(side=tk.LEFT, padx=10)
    
    def set_speed_mode(self, mode):
        """设置速度模式"""
        self.speed_mode = mode
        if mode == "fast":
            self.fast_speed_scale.config(state=tk.NORMAL)
            self.slow_speed_scale.config(state=tk.DISABLED)
        else:
            self.fast_speed_scale.config(state=tk.DISABLED)
            self.slow_speed_scale.config(state=tk.NORMAL)
    
    def toggle_mode(self):
        """切换有限/无限模式"""
        if self.mode_var.get() == "infinite":
            self.count_spin.config(state=tk.DISABLED)
            self.infinite_mode = True
            self.progress.config(mode="indeterminate")
        else:
            self.count_spin.config(state=tk.NORMAL)
            self.infinite_mode = False
            self.progress.config(mode="determinate")
    
    def send_keys(self):
        """发送按键组合"""
        try:
            self.user32.keybd_event(0x11, 0, 0, 0)  # Ctrl
            self.user32.keybd_event(0x56, 0, 0, 0)  # V
            time.sleep(0.005)
            self.user32.keybd_event(0x56, 0, 2, 0)  # 释放V
            self.user32.keybd_event(0x11, 0, 2, 0)  # 释放Ctrl
            
            time.sleep(0.005)
            self.user32.keybd_event(0x0D, 0, 0, 0)  # 回车
            time.sleep(0.005)
            self.user32.keybd_event(0x0D, 0, 2, 0)  # 释放回车
        except Exception as e:
            self.show_error(self.get_text("error_send_failed").format(str(e)))
    
    def start_spamming(self):
        if self.is_spamming:
            return
            
        text = self.text_entry.get()
        try:
            if self.speed_mode == "fast":
                speed = int(self.fast_speed_scale.get())
            else:
                speed = float(self.slow_speed_scale.get())
                
            total_count = 999999 if self.infinite_mode else int(self.count_spin.get())
        except ValueError:
            self.show_error(self.get_text("error_invalid_number"))
            return
        
        if not text.strip():
            self.show_error(self.get_text("error_no_text"))
            return
        
        if self.speed_mode == "fast" and (speed < 1 or speed > 500):
            self.show_error(self.get_text("error_speed_range_fast"))
            return
        elif self.speed_mode == "slow" and (speed < 0.1 or speed > 10):
            self.show_error(self.get_text("error_speed_range_slow"))
            return
        
        # 构建确认消息
        if self.speed_mode == "fast":
            confirm_msg = self.get_text("confirm_msg_fast").format(speed)
        else:
            confirm_msg = self.get_text("confirm_msg_slow").format(speed)
            
        if self.infinite_mode:
            confirm_msg += self.get_text("confirm_infinite")
        else:
            confirm_msg += self.get_text("confirm_limited").format(total_count)
        
        confirm_msg += self.get_text("confirm_warning")
        
        if not messagebox.askyesno(self.get_text("title"), confirm_msg):
            return
        
        # 设置状态
        self.is_spamming = True
        self.stop_flag = False
        self.start_btn.config(state=tk.DISABLED)
        self.pause_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.NORMAL)
        self.status_label.config(text=self.get_text("status_ready"), fg="orange")
        self.time_label.config(text="")
        
        if not self.infinite_mode:
            self.progress["maximum"] = total_count
            self.progress["value"] = 0
        
        # 将文本复制到剪贴板
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        
        # 在后台线程中运行刷屏
        threading.Thread(target=self.run_spamming, args=(total_count, speed), daemon=True).start()
    
    def run_spamming(self, total_count, speed):
        """实际刷屏线程"""
        try:
            # 计算每次发送的间隔（秒）
            if self.speed_mode == "fast":
                interval = 1.0 / speed if speed > 0 else 0.1
            else:
                interval = speed
            
            # 等待5秒让用户切换窗口
            for i in range(5, 0, -1):
                if self.stop_flag: return
                self.update_status(self.get_text("status_starting").format(i))
                time.sleep(1)
            
            start_time = time.time()
            sent_count = 0
            last_update_time = time.time()
            
            self.update_status(self.get_text("status_spamming"), "green")
            if self.infinite_mode:
                self.progress.start()
            
            while (self.infinite_mode or sent_count < total_count) and not self.stop_flag:
                if not self.is_paused:
                    self.send_keys()
                    sent_count += 1
                    
                    # 更新进度
                    if not self.infinite_mode:
                        if self.speed_mode == "fast":
                            self.update_progress(sent_count, total_count, speed)
                        else:
                            self.update_progress(sent_count, total_count, 1/interval if interval > 0 else 0)
                        self.progress["value"] = sent_count
                    
                    # 每秒更新一次时间显示
                    current_time = time.time()
                    if current_time - last_update_time >= 1.0:
                        elapsed_seconds = current_time - start_time
                        elapsed_str = str(timedelta(seconds=int(elapsed_seconds)))
                        self.root.after(0, lambda: self.time_label.config(
                            text=self.get_text("elapsed_time").format(elapsed_str)))
                        last_update_time = current_time
                    
                    # 计算精确的间隔时间
                    next_time = start_time + (sent_count * interval)
                    sleep_time = max(0, next_time - time.time())
                    time.sleep(sleep_time)
                
                else:
                    time.sleep(0.1)
            
            # 刷屏完成
            if not self.stop_flag:
                elapsed = time.time() - start_time
                actual_speed = sent_count / elapsed if elapsed > 0 else 0
                if self.infinite_mode:
                    self.progress.stop()
                    self.update_status(self.get_text("status_infinite_stopped").format(sent_count), "blue")
                else:
                    self.update_status(self.get_text("status_complete").format(actual_speed), "blue")
                
                # 显示总时间
                elapsed_str = str(timedelta(seconds=int(elapsed)))
                self.root.after(0, lambda: self.time_label.config(
                    text=self.get_text("total_time").format(elapsed_str)))
        
        except Exception as e:
            self.show_error(self.get_text("error_send_failed").format(str(e)))
        finally:
            self.is_spamming = False
            self.root.after(0, self.reset_ui)
    
    def pause_resume(self):
        """暂停/继续"""
        self.is_paused = not self.is_paused
        if self.is_paused:
            self.pause_btn.config(text=self.get_text("resume_btn"))
            self.status_label.config(text=self.get_text("status_paused"), fg="red")
            if self.infinite_mode:
                self.progress.stop()
        else:
            self.pause_btn.config(text=self.get_text("pause_btn"))
            self.status_label.config(text=self.get_text("status_spamming"), fg="green")
            if self.infinite_mode:
                self.progress.start()
    
    def stop_spamming(self):
        """停止刷屏"""
        self.stop_flag = True
        self.status_label.config(text=self.get_text("status_stopping"), fg="orange")
        if self.infinite_mode:
            self.progress.stop()
    
    def reset_ui(self):
        """重置UI状态"""
        self.start_btn.config(state=tk.NORMAL)
        self.pause_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.DISABLED)
        self.pause_btn.config(text=self.get_text("pause_btn"))
        self.is_paused = False
        if not self.infinite_mode:
            self.progress["value"] = 0
        # 重置时间显示
        self.time_label.config(text="")
    
    def update_status(self, message, color="black"):
        """更新状态标签"""
        self.root.after(0, lambda: self.status_label.config(text=message, fg=color))
    
    def update_progress(self, sent, total, speed):
        """更新进度显示"""
        if self.current_language == "zh":
            title = f"超高速刷屏器 - 已发送 {sent}/{total} 条 ({speed:.1f}条/秒) Tim-CN制作"
        else:
            title = f"Ultra Fast Spammer - Sent {sent}/{total} ({speed:.1f} msg/sec) Made by Tim-CN"
        self.root.after(0, lambda: self.root.title(title))
    
    def show_error(self, message):
        """显示错误信息"""
        self.root.after(0, lambda: messagebox.showerror(self.get_text("title"), message))
        self.root.after(0, self.reset_ui)

if __name__ == "__main__":
    root = tk.Tk()
    app = veryveryfastspammer(root)
    root.mainloop()